define(['can-library'], function (can) {
	return can;
});